#include <string>

namespace PathAdapter {
std::string __attribute__((visibility("default"))) GetDir(std::string& getDirFuncName);

}