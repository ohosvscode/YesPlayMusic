#include "getpath.h"

#include <functional>
#include "aki/jsbind.h"
namespace PathAdapter {
  std::string GetDir(std::string& getDirFuncName) {

    //同步方式
    if (auto getDirFunc = aki::JSBind::GetJSFunction(getDirFuncName)) {
      auto path = getDirFunc->Invoke<std::string>();
      return path;
    }
    return "";

    //异步方式
    std::promise<std::string> promise;
    std::function<void(std::string)> callback = [&promise](std::string path) {
      promise.set_value(path);
    };

    if (auto jsFunc = aki::JSBind::GetJSFunction(getDirFuncName)) {
      jsFunc->Invoke<void>(callback);
    } else {
      return "";
    }

    auto future = promise.get_future();
    auto status = future.wait_for(std::chrono::seconds(5));
    if (status == std::future_status::timeout) {
      return "timeout";
    }
    return future.get();
  }
}