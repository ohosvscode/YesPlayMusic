const { app, BrowserWindow, dialog } = require('electron');

const sqlite3 = require('sqlite3').verbose();


setTimeout(() => {
    const db = new sqlite3.Database(':memory:');
}, 15000);


app.whenReady().then(() => {
    const mainWindow = new BrowserWindow({
        width: 800,
        height: 600,
        webPreferences: {
            nodeIntegration: true,
            nodeIntegrationInWorker: true,
            contextIsolation: false,
        }
    })
    mainWindow.loadFile('index.html')
    // dialog.showErrorBox('data', addon.hello());
})
